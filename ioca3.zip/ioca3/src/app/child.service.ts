import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChildService {

  constructor() {}

    getChild(){
      return"child from service";
    }
   }

