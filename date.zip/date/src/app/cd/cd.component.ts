import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cd',
  templateUrl: './cd.component.html',
  styleUrls: ['./cd.component.css']
})
export class CdComponent implements OnInit {
  Date1 :Date =new Date();

  constructor() { }

  ngOnInit(): void {
  }

}
